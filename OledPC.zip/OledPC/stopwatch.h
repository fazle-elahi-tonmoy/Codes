int s_sec=0;
int s_min=0;
float s_milis=0;

long tt=0;
long tt2=0;

String Seconds_string;
String Minutes_string;
int s_fase=0;
