byte playerX=12;
const byte playerW PROGMEM=14;
byte ballX=30;
byte ballY=50;
byte ballDirectionX=1;
byte ballDirectionY=1;
byte gameScore=0;
bool controler=0;

byte enX[14] ={4,16,28,40,52,8,20,32,44,16,28,40,20,32};
byte enY[14]={18,18,18,18,18,22,22,22,22,26,26,26,30,30};
 bool enL[14]={1,1,1,1,1,1,1,1,1,1,1,1,1,1};
