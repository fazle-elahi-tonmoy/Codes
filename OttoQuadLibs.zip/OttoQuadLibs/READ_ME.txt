Copy the contents of the folder 'LIBRARIES' into the Arduino IDE library folder

Keep the contents of the firmwareVER_9 together as the sketch will not compile without these 
additional files being toghether.

If the IDE creates a new folder, make sure you copy all files into the same folder and restart the IDE.

When you double click the firmwareVER_9.ino  sketch you will see additional tabs within the IDE sketch, please 
do not make any changes to these as they are important core files, once I have finished perfecting the Quad
movements and functionality I will create the libraries.


DO NOT CONNECT THE BLUETOOTH MODULE until you have uploaded the sketch, you can not upload with the bluetooth
module connected to the Nano RX and TX pins.
Each time you need to upload a sketch remember to remove the bluetooth module.


Please note, this is a work in progress, some files/ APP  and STL could change.

Keep checking back for new versions.


Thanks
Jason